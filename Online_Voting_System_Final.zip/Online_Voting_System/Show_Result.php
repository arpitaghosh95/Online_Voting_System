<?php
session_start();
include "connection.php";
error_reporting(0);
if((!$_SESSION['login']) && (!$_SESSION['login_id']))
{
    echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/HOME.html"</script>';

/*if(((!isset($_SESSION['login'])) &&(!isset($_SESSION['login_id'])))){
  echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/HOME.html"</script>';
  
  //header("location:/ONLINE_VOTING_SYSTEM/HOME.html");*/
}

?>



<html>
<head>
    <style type="text/css">
    body{
	background: url('Pictures/back3.jpg') no-repeat center center/cover;
	
    }

    h1{
        margin-top:60px;
        font-size: 50px;
        font-weight: 700;
    }
    table{
        border-collapse: collapse;
        width: 70%;
        height:40%;
        color: #000000;
        font-family:monospace;
        font-size: 25px;
        text-align: left;
    }
    th{
        background-color: #39A6A3;
        color: #ffffff;
    }
    tr:nth-child(even)
    {
        background-color: #ededed;
    }
    </style>
</head>
    <body>
        <center> <h1>RESULT</h1>
        <table>
            <tr>
                <th>PARTY_NAME</th>
                <th>TOTAL_VOTE</th>
            </tr>
            <?php
            error_reporting(0);
            include "connection.php";
                $sql="select PARTY_NAME,TOTAL_VOTE from `vote_count`";
                $res=mysqli_query($conn,$sql);
                if(mysqli_num_rows($res)>0){
                while($row=mysqli_fetch_assoc($res))
                {
                    echo"<tr><td>" . $row['PARTY_NAME'] . "</td><td>" . $row['TOTAL_VOTE'] . "</td></th>";
                }
            }
            ?>
        </table>
        </center>
    </body>
</html>
  <!--if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res))
        {
            echo $row['PARTY_NAME'];
            echo $row['TOTAL_VOTE'];
        }
    }
    $data = array();
    foreach($res as $row){
        $data[] = $row;
    }
    print_r($data);-->
