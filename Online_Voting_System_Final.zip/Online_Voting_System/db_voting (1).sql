-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2021 at 10:15 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE `admin_details` (
  `USERNAME` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`USERNAME`, `PASSWORD`) VALUES
('admin', '12345'),
('arpita', '12345'),
('dipa', '12345'),
('rupa', '12345'),
('ravi', '12345'),
('souronil', '12345'),
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `candidate_details`
--

CREATE TABLE `candidate_details` (
  `ADHAR_ID` varchar(16) NOT NULL,
  `FNAME` varchar(50) NOT NULL,
  `LNAME` varchar(50) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `CONTACT` varchar(10) NOT NULL,
  `PASSWORD` varchar(15) NOT NULL,
  `DOB` date NOT NULL,
  `PARTY_NAME` varchar(50) NOT NULL,
  `CITY` varchar(20) NOT NULL,
  `PIN_CODE` int(6) NOT NULL,
  `STATE` varchar(20) NOT NULL,
  `GENDER` varchar(7) NOT NULL,
  `PICTURE` varchar(255) NOT NULL,
  `UNIQUE_ID` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate_details`
--

INSERT INTO `candidate_details` (`ADHAR_ID`, `FNAME`, `LNAME`, `EMAIL`, `CONTACT`, `PASSWORD`, `DOB`, `PARTY_NAME`, `CITY`, `PIN_CODE`, `STATE`, `GENDER`, `PICTURE`, `UNIQUE_ID`) VALUES
('dr1234', 'Doraemon', 'Nobi', 'doraemonnobi@gmail.com', '9166666666', 'd1234', '2021-06-08', 'HUNGAMA        ', 'Kolkata           ', 700006, 'West Bengal', 'male', 'Pictures/Doraemon1.png', '34f11cf156d64c8c539da14fe2359c9a'),
('sn1234', 'Sinchan', 'Nohara', 'sinchannohara@gmail.com', '9830145166', 's1234', '2021-06-01', 'POGO', 'Howrah', 700002, 'West Bengal', 'male', 'Pictures/Sinchan1.png', '694c23751fd9be6b778d6b8ee7ed9269'),
('jr1234', 'Jerry', 'Jack', 'jerryjack@gmail.com', '9434619220', 'j1234', '2021-06-02', 'CARTOON NETWORK', 'Hooghly', 712706, 'West Bengal', 'male', 'Pictures/Jerry1.jpg', '760ae07db295bc276a33b83f323cbbf0');

-- --------------------------------------------------------

--
-- Table structure for table `voter_details`
--

CREATE TABLE `voter_details` (
  `voter_id` varchar(50) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pin_code` int(6) NOT NULL,
  `state` varchar(20) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voter_details`
--

INSERT INTO `voter_details` (`voter_id`, `f_name`, `l_name`, `email`, `dob`, `password`, `gender`, `city`, `pin_code`, `state`, `status`) VALUES
('DB12345', 'Arpita ', 'Ghosh', 'arpitaghosh195@gmail.com', '1995-10-20', 'a12345', 'Female', 'Chinsura', 712706, 'West Bengal', 1),
('SA2468', 'Souronil', 'Agasti', 'principal@mismsd.in', '1998-07-05', 's5678', 'Male', 'Kolkata', 700001, 'West Bengal', 1),
('AG6789', 'Abhishek', 'Ghosh', 'spbdscal@gmail.com', '2000-08-31', 'ag1234', 'male', 'Hooghly', 712706, 'West Bengal', 1),
('cc1234', 'abcd', 'xyz', 'subranil.agasti@gmail.com', '2021-06-02', '12345', 'other', 'Howrah', 700004, 'West Bengal', 1),
('yy333', 'ram', 'sharma', 'ram.sharma@gmail.com', '2021-06-04', '0000', 'male', 'Howrah', 700004, 'West Bengal', 1),
('xx222', 'Madhu', 'Mal', 'madhu.mal@gmail.com', '2021-06-06', '2222', 'female', 'Kolkata', 700005, 'West Bengal', 1),
('zz333', 'Ritu', 'Roy', 'rituroy@gmail.com', '2021-06-08', '3333', 'female', 'Hooghly', 712706, 'West Bengal', 1),
('aa2323', 'Harry', 'Potter', 'harry.potter@gmail.com', '2021-06-08', '12345', 'male', 'Hooghly', 712706, 'West Bengal', 1),
('BB666', 'Henry', 'Fredric', 'henryfredrick@gmail.com', '2021-06-04', '4444', 'male', 'Hooghly', 712706, 'West Bengal', 1),
('EE555', 'Rita', 'Ghosh', 'principal@mismsd.in', '2021-06-02', '1234', 'female', 'Hooghly', 712706, 'West Bengal', 1),
('HH444', 'Henry', 'Donald', 'igmhs@hotmail.com', '2021-06-06', '1234', 'male', 'Hooghly', 712706, 'West Bengal', 1),
('ad1234', 'Arohi', 'Ghosh', 'arohighosh@gmail.com', '2021-06-02', '12345', 'on', 'Hooghly', 712706, 'West Bengal', 1),
('dt1234', 'Ditti', 'Roy', 'dittiroy@gmail.com', '2021-06-02', '12345', 'female', 'Hooghly', 712706, 'West Bengal', 1),
('rr1234', 'Riya', 'Roy', 'riyaroy@gmail.com', '2021-06-02', '12345', 'female', 'Hooghly', 712706, 'West Bengal', 1),
('aa12345', 'Henry', 'sharma', 'principal@mismsd.in', '2021-06-04', '12345', 'male', 'Kolkata', 700004, 'West Bengal', 1),
('ff1234', 'Jenifer', 'Winget', 'jeniferwinget@gmail.com', '2021-06-10', 'j12345', 'female', 'Kolkata', 700004, 'West Bengal', 1),
('jj1234', 'Srija ', 'Sarkar', 'srijasarkar@gmail.com', '2021-06-10', 's1234', 'female', 'Kolkata', 700004, 'West Bengal', 1),
('gg1234', 'Gunja ', 'Roy', 'gunjaroy@gmail.com', '2021-06-18', 'g1234', 'female', 'Howrah', 700002, 'West Bengal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vote_count`
--

CREATE TABLE `vote_count` (
  `UNIQUE_ID` varchar(100) NOT NULL,
  `CANDIDATE_NAME` varchar(50) NOT NULL,
  `PARTY_NAME` varchar(50) NOT NULL,
  `TOTAL_VOTE` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote_count`
--

INSERT INTO `vote_count` (`UNIQUE_ID`, `CANDIDATE_NAME`, `PARTY_NAME`, `TOTAL_VOTE`) VALUES
('34f11cf156d64c8c539da14fe2359c9a', 'Doraemon Nobi', 'HUNGAMA', 0),
('694c23751fd9be6b778d6b8ee7ed9269', 'Sinchan Nohara', 'POGO', 2),
('760ae07db295bc276a33b83f323cbbf0', 'Jerry Jack', 'CARTOON NETWORK', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
