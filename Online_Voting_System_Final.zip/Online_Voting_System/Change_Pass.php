<?php
session_start();
include "connection.php";
if(!$_SESSION['searchname'])
{
    echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/Forget_Pass.php/"</script>';
}
?>

<!DOCTYPE html>
<html lang="en">

<body>
<form method="post">
<label>Password: </label>
<br>
<input type="password" name="newpwd" placeholder="Enter New Password">
<br><br>
<label>Confirm Password: </label>
<br>
<input type="password" name="cnfrm" placeholder="Re-Enter The Password">
<br><br>
<input type="submit" name="updatepass" value="CHANGE">
</form>
</body>
</html>
<?php
error_reporting(0);
$searchedvalue=$_SESSION['searchname'];
$newpassword=$_POST['newpwd'];
$cngpassword=$_POST['cnfrm'];
if(isset($_POST['updatepass']))
{
    if($newpassword!==$cngpassword)
    {
        echo '<script>alert("password not matched")</script>';
        echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/Forget_Pass.php/"</script>';
    }
    else
    {
        $sql="update candidate_details set password='$newpassword' where ADHAR_ID='$searchedvalue'";
        $res=mysqli_query($conn,$sql);

        if($res)
        {
            echo'<script>alert("Password Changed Successfully")</script>';
            echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/CandidateLogout.php/"</script>';
        }
    }
}

?>