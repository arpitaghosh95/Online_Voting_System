<?php
session_start();
error_reporting(0);
$conn=mysqli_connect("localhost", "root", "", "db_voting") or mysqli_connect_error();
if(!isset($_SESSION['user']))
{
  header("location:/ONLINE_VOTING_SYSTEM/ADMIN/AdminLogin.php");
}

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="adminStyle.css">
</head>
<body>

  <button class="button" id="admin">ADD ADMIN</button>
  <script >
    document.getElementById("admin").onclick = function () 
    {
        location.href = "AdminRegister.php";
    };
  </script>
  <button class="button" id="candidate">UPDATE CANDIDATE</button>
  <script >
    document.getElementById("candidate").onclick = function () {
        location.href = "Update_Candidate_Input.php";
    };
  </script>
  <a href="/ONLINE_VOTING_SYSTEM/ADMIN/AdminLogout.php/" >LOGOUT</a>
</body>
</html>



