<?php
  error_reporting(0);
  session_start();
  if($_SESSION['passnot']){
    unset($_SESSION['passnot']);
  }
  if(!isset($_SESSION['user']))
{
  header("location:/ONLINE_VOTING_SYSTEM/ADMIN/AdminLogin.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="../CSS/adminStyle.css">
</head>
<body>
<form method="post">
<h1>Register Here</h1>
<input type="text" name="user" class="box" placeholder="Enter Username">
<input type="password" name="password" class="box" placeholder="Enter password">
<input type="password" name="confirm" class="box" placeholder="Re-Enter Your Password">
<input type="submit" name="submit" value="REGISTER" id="submit"> 
<br></br>

</form>
</body>
</html>


<?php
error_reporting(0);
session_start();
$conn=mysqli_connect("localhost", "root", "", "db_voting") or mysqli_connect_error();
$user=$_POST['user'];
$password=$_POST['password'];
$conpas=$_POST['confirm'];

if(isset($_POST['submit']))
{
  if($password!==$conpas)
    {
      $_SESSION['passnot'] = "password not matched";
      header("location:/ONLINE_VOTING_SYSTEM/ADMIN/AdminRegister.php");
    }
    else
    {
        $sql = "insert into `admin_details` (USERNAME,PASSWORD) values ('$user','$password')";
        $res = mysqli_query($conn,$sql);

        if($res)
        {
            echo "NEW RECORD CREATED SUCCESSFULLY";
        }
        else
        {
            echo "Something went wrong";
        }
    }    
}
?>
