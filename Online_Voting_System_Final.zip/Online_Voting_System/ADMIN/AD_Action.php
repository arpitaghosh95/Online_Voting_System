<?php

$conn=mysqli_connect("localhost", "root", "", "db_voting") or mysqli_connect_error();
$user=$_POST['user'];
$password=$_POST['password'];
$conpas=$_POST['confirm'];

if(isset($_POST['REGISTER']))
{
        $sql = "insert into `admin_details` (USERNAME,PASSWORD) values ('$user','$password')";
        $res = mysqli_query($conn,$sql);

        if($res)
        {
            echo'<script>alert("NEW RECORD CREATED SUCCESSFULLY")</script>';
            //echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/ADMIN/AdminRegister.php"</script>';
        }
        else
        {
            echo "Something went wrong";
        }
}

?>
