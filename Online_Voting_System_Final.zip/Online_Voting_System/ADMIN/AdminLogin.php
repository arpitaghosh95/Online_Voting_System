<!DOCTYPE html>
<html>
<head>
    <title>Login_form</title>
    <link rel="stylesheet" href="../CSS/adminStyle.css">
</head>
<body>
<form method="post">
<h1>Login Form</h1>
<input type="text" name="user" class="box" placeholder="Enter Username">
<input type="password" name="password" class="box" placeholder="Enter password">
<input type="submit" name="submit" value="LOGIN" id="submit"> 
<br></br>
</form> 
</body>
</html>
<?php
session_start();
error_reporting(0);
$conn=mysqli_connect("localhost", "root", "", "db_voting") or mysqli_connect_error();
$user=$_POST['user'];
$password=$_POST['password'];
if(isset($_POST['submit']))
{
    $sql = "select * from `admin_details` where `USERNAME`='$user' and `PASSWORD`='$password'";
    $res = mysqli_query($conn,$sql);
    if(mysqli_num_rows($res))
    {
        $_SESSION['user']=$user;
        header("location:/ONLINE_VOTING_SYSTEM/ADMIN/WELCOME.php");
    }
    else
    {
        echo "Something Went Wrong";
    }
}
?>