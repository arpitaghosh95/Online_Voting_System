<?php
session_start();
session_destroy();
header("location:/ONLINE_VOTING_SYSTEM/ADMIN/AdminLogin.php");
?>