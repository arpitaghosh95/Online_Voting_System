<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['user']))
{
  header("location:/ONLINE_VOTING_SYSTEM/ADMIN/AdminLogin.php");
}

?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
    body{
  	background: url('../Pictures/back3.jpg') no-repeat center center/cover;
	
    }
    table{
        /*border-collapse: collapse;*/
        width: 50%;
        color: #000000;
        font-family:monospace;
        font-size: 25px;
        text-align: center;
        margin-top:30px;
    }
    th{
        background-color: #39A6A3;
        color: #000000;
    }
    tr:nth-child(even)
    {
        background-color: #ededed;
    }

</style>
</head>
<body>


<?php
session_start();
$conn=mysqli_connect("localhost","root","","db_voting") or mysqli_connect_error();
error_reporting(0);

$id=$_POST['unique'];

if(isset($_POST['submit'])){
    $sql="select * from `candidate_details` where `UNIQUE_ID` = '$id'";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0){
        $_SESSION['login_id']=$id;
        while($row=mysqli_fetch_assoc($res))
        {
        echo"<center>";
        echo"<table>";
   		echo"<tr>";
   		echo"<th>IMAGE</th>";
        echo"<td><img style ='width:200px;' src='/Online_Voting_System/".$row['PICTURE']."'></td>";
        echo"</tr>";
        echo"<tr>";
        echo"<th>ADHAR ID</th>";
        echo"<td>".$row['ADHAR_ID']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>FNAME</th>";
        echo"<td>".$row['FNAME']."</td>";
        echo"</tr>";
        echo"<tr>";
        echo"<th>LNAME</th>";
        echo"<td>".$row['LNAME']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>EMAIL</th>";
        echo"<td>".$row['EMAIL']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>CONTACT</th>";
        echo"<td>".$row['CONTACT']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>DOB</th>";
        echo"<td>".$row['DOB']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>PARTY</th>";
        echo"<td>".$row['PARTY_NAME']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>CITY</th>";
        echo"<td>".$row['CITY']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>PIN_CODE</th>";
        echo"<td>".$row['PIN_CODE']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>STATE</th>";
        echo"<td>".$row['STATE']."</td>";
        echo"</tr>";
        echo"<tr>";
   		echo"<th>UNIQUE_ID</th>";
        echo"<td>".$row['UNIQUE_ID']."</td>";
        echo"</tr>";
        echo"</table><br>";
        echo"<td><a href='/ONLINE_VOTING_SYSTEM/ADMIN/AdminUpdateCandidate.php/? em=$row[EMAIL] & cnt=$row[CONTACT] & party=$row[PARTY_NAME] & ct=$row[CITY] & pin=$row[PIN_CODE] & st=$row[STATE]'>UPDATE / EDIT</a></td>";
        echo"</center>";
        }
    }
}
?>
</body>
</html>