<?php
session_start();
error_reporting(0);
$conn=mysqli_connect("localhost", "root", "", "db_voting") or mysqli_connect_error();
if(!isset($_SESSION['user']))
{
  header("location:/ONLINE_VOTING_SYSTEM/ADMIN/AdminLogin.php");
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    background: url('../Pictures/back_admin.jpg') no-repeat center center/cover;
    margin-top:30px;
    font-size: 30px;
    font-weight: 50;
}
.input{
    width:20%;
}
.btn{
    margin-top:20px;
    padding: 5px 20px;
    font-size: 15px;
    font-weight: 50;
}
</style>
</head>
<body>
<form action="/ONLINE_VOTING_SYSTEM/ADMIN/Update_Candidate_Action.php" method="POST">
<center>
Enter Candidate Unique_Id: <input type="text" class="input" name="unique" id="u_id">
<br>
<input type="submit" name="submit" class="btn" value="SUBMIT">
</center>
</form>
</body>
</html>

