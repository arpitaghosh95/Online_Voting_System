<?php
    session_start();
    error_reporting(0);
    echo $_SESSION['passnot'];
    if($_SESSION['passnot']){
        unset($_SESSION['passnot']);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/vote_reg_style.css">
    <title>Document</title>

</head>
<body>
<div class="regform">
    <h2>Registration Form</h2>
</div>
<div class="main">
    
        <form action="CR_Action.php" method="POST" enctype="multipart/form-data">
        <h3 class="name"> Adhar Id </h3>
                <input class="voter" type="text" name="a_id">
            <div id="name">
                <h3 class="name">
                Name </h3>
                <input class="firstname" type="text" name="fname"><br>
                <label class="firstlabel">first name</label>
                <input class="lastname" type="text" name="lname"><br>
                <label class="lastlabel">last name</label>
            </div>
                <h3 class="name"> Email</h3>
                <input class="email" type="email" name="email">
                
                <h3 class="name"> Pnone_No</h3>
                <input class="phone" type="text" name="ph">

                <h3 class="name"> Upload Image</h3>
                <input class="img" type="file" name="filetoupload">

                <h3 class="name"> Party Name</h3>
                <input class="party" type="text" name="party">
                
                <h3 class="name"> Password</h3>
                <input class="password" type="password" name="pwd">
                
                <h3 class="name"> Confirm Password</h3>
                <input class="confirm" type="password" name="confirm">

                <h3 class="name"> D.O.B</h3>
                <input class="dob" type="date" name="dob">

                <h3 id="gender"> Gender </h3>
                <label class="radio">
                <input class="radio-one" type="radio" checked="checked" name="gender" value="male">
                <span class="checkmark">Male</span>                
                </label>
                    
                <label class="radio">
                <input class="radio-two" type="radio" name="gender" value="female">
                <span class="checkmark">Female</span>                
                </label>

                <h3 class="name"> City</h3>
                <select class="option" name="city">
                <option disabled="disabled" selected="selected">--Choose option--</option>
                <option>Hooghly</option>
                <option>Howrah</option>
                <option>Kolkata</option>
                <option>Gujrat</option>
                <option>Delhi</option>
                </select>

                <h3 id="pin"> Pin </h3>
                <input class="pin" type="number" name="pin">

                <h3 class="name"> State </h3>
                <input class="state" type="text" name="state">
                <br></br>

                <center>
                <button type="submit" name="REGISTER">Register</button>              
                <button type="reset">Reset</button>
                </center>
                    
                    
        </form>
</div>
</body>
</html>



