<?php
session_start();
include "connection.php";
error_reporting(0);
if(!isset($_SESSION['login'])){
  //echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/VoterLogin.php"</script>';
  
  header("location:/ONLINE_VOTING_SYSTEM/VoterLogin.php");
}

?>



<!DOCTYPE html>
<html>
<head>
<style>
body{
	background: url('Pictures/back3.jpg') no-repeat center center/cover;
	
}

table{
        /*border-collapse: collapse;*/
        width: 50%;
		border: 1px solid black;
		border-radius:6px;
        color: #000000;
        font-family:monospace;
        font-size: 25px;
        text-align: left;
		margin-top:10%; 
    }
    th{
        background-color: #125D98;
        color: #ffffff;
    }
    tr:nth-child(even)
    {
        background-color: #ededed;
    }
	th, td{
		
		padding: 5px;
  		text-align: left;
	}
</style>
</head>
<body>
<?php
session_start();
error_reporting(0);
include "connection.php";
	$value=$_SESSION['login'];
   	$sql="select * from `voter_details` where `voter_id`= '$value'";
   	$res=mysqli_query($conn,$sql);
   	if(mysqli_num_rows($res)>0){
		while($row=mysqli_fetch_assoc($res))
        {
			echo"<center>";
			echo"<table>";
			echo"<tr>";
			echo"<th>VOTER_ID</th>";
			echo"<td>".$row['voter_id']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>F_NAME</th>";
			echo"<td>".$row['f_name']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>L_NAME</th>";
			echo"<td>".$row['l_name']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>EMAIL</th>";
			echo"<td>".$row['email']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>DOB</th>";
			echo"<td>".$row['dob']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>GENDER</th>";
			echo"<td>".$row['gender']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>CITY</th>";
			echo"<td>".$row['city']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>PIN_CODE</th>";
			echo"<td>".$row['pin_code']."</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<th>STATE</th>";
			echo"<td>".$row['state']."</td>";
			echo"</tr>";
			echo"</table>";
			echo"</center>";
        }
    }
   	
?>
</body>
</html>

