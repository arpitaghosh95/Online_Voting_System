<?php
session_start();
error_reporting(0);
include "connection.php";
$id=$_REQUEST['id'];
$fname=$_REQUEST['fname'];
$lname=$_REQUEST['lname'];
$email=$_REQUEST['email'];
$dob=$_REQUEST['dob'];
$password=$_REQUEST['pwd'];
$conpas=$_REQUEST['confirm'];
$gender=$_REQUEST['gender'];
$city=$_REQUEST['city'];
$pin=$_REQUEST['pin'];
$state=$_REQUEST['state'];

if(isset($_POST['REGISTER']))
{
    
	if($password!==$conpas)
	{
		$_SESSION['passnot']="password not matched";
		header("location:/ONLINE_VOTING_SYSTEM/VoterRegister.php");
	}
    else{
        $update = "select * from `voter_details` where `voter_id` ='$id'";
        $result = mysqli_query($conn,$update);
        if(mysqli_num_rows($result)){
            echo '<script> alert("Already Registered") </script>';
            header("location:/ONLINE_VOTING_SYSTEM/VoterRegister.php");
        }
        else{
            $sql = "insert into `voter_details`(voter_id,f_name,l_name,email,dob,password,gender,city,pin_code,state ) values ('$id','$fname','$lname','$email','$dob','$password','$gender','$city','$pin','$state')";
            $res = mysqli_query($conn,$sql);
        }
        if($res){
            echo '<script>alert("REGISTERED SUCCESSFULLY")</script>';
        }
        /*else{
            echo "Something went wrong";
        }*/
        
    }
        
}

?>