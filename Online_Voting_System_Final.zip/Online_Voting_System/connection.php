<?php
$conn=mysqli_connect("localhost", "root", "", "db_voting") or mysqli_connect_error();
?>