<!DOCTYPE html>
<html>
<head> 
<title>Login_form</title>
<link rel="stylesheet" href="CSS/candi_login_style.css">  
</head>
<body>
<form method="post">
<h1>Login Form</h1>
<input type="text" name="u_id" class="box" placeholder="Enter unique id">
<input type="password" name="password" class="box" placeholder="Enter password">
<input type="submit" name="submit" value="LOGIN" id="submit"> 
<br></br>
<center><a style="margin-left:20;" class="forgot" href="/ONLINE_VOTING_SYSTEM/Forget_Pass.php">Forgot Password?</a></center>
</form>
</body>
</html>


<?php
session_start();
error_reporting(0);
include "connection.php";
$u_id=$_POST['u_id'];
$password=$_POST['password'];
if(isset($_POST['submit']))
{
    $sql = "select * from `candidate_details` where `UNIQUE_ID`='$u_id' and `PASSWORD`='$password'";
    $res = mysqli_query($conn,$sql);
    if(mysqli_num_rows($res))
    {
        $_SESSION['login_id']=$u_id;
        header("location:/ONLINE_VOTING_SYSTEM/Candidate_Welcome.php");
    }
    else
    {
        echo'<script>alert("WRONG PASSWORD")</script>';
    }
}
?>