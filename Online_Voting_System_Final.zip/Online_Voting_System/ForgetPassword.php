<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body{
            /*background-color:#87CEFA;*/
            background: url('Pictures/back_admin.jpg') no-repeat center center/cover;
        }
        .main{
            font-size: 30px;
            font-weight: 50;
        }
        .btn{
            margin-top:20px;
            padding: 5px 20px;
            font-size: 15px;
            font-weight: 50;
        }
    </style>
</head>

<body>
<form method="post">
<center><h1>FORGOT PASSWORD</h1>
<br></br>
<label class="main">Enter Your Voter Id: </label>
<input type="text" name="v_id">
<br></br>
<input type="submit" class="btn" name="acsearch" value="CONTINUE"></center>
</form>
</body>
</html>
<?php
session_start();
error_reporting(0);
include "connection.php";
$searchname=$_POST['v_id'];
if(isset($_POST['acsearch']))
{
    $sql="select * from `voter_details` where `voter_id`='$searchname' ";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res))
    {
        //echo "$searchname";
        $_SESSION['searchname']=$searchname;
        echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/ChangePassword.php/"</script>';
    }
}

?>