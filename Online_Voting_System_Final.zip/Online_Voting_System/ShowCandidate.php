<?php
session_start();
include "connection.php";
error_reporting(0);
if((!$_SESSION['login']) && (!$_SESSION['login_id']))
{
    echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/HOME.html"</script>';
}
?>

<html>
<head>
<style type="text/css">
    body{
	background: url('Pictures/back3.jpg') no-repeat center center/cover;
	
    }
    table{
        border-collapse: collapse;
        width: 100%;
        color: #000000;
        font-family:monospace;
        font-size: 25px;
        text-align: left;
        margin-top:30px;
    }
    th{
        background-color: #39A6A3;
        color: #ffffff;
    }
    tr:nth-child(even)
    {
        background-color: #ededed;
    }
    </style>
</head>
	<body>
	<table>
            <tr>
                <th>IMAGE</th>
                <th>FNAME</th>
				<th>LNAME</th>
				<th>DOB</th>
				<th>PARTY</th>
				<th>CITY</th>
				<th>PIN_CODE</th>
				<th>STATE</th>
            </tr>
<?php
error_reporting(0);
include "connection.php";
   	$sql="select * from `candidate_details`";
   	$res=mysqli_query($conn,$sql);
   	if(mysqli_num_rows($res)>0){
   		while($row=mysqli_fetch_assoc($res))
   		{
			echo"<tr><td>" . "<img style='width:130px; height:130px;'src=".$row['PICTURE'].">" . "</td><td>" . $row['FNAME'] . "</td><td>" . $row['LNAME'] . "</td><td>" . $row['DOB'] ."</td><td>" . $row['PARTY_NAME'] . "</td><td>" . $row['CITY'] . "</td><td>" . $row['PIN_CODE'] . "</td><td>" . $row['STATE'] . "</td></th>";
   			
   		}
   	}  
?>
</table>
</body>
</html>