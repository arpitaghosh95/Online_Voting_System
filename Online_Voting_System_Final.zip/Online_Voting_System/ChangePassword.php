<?php
session_start();
error_reporting(0);
include "connection.php";
if(!$_SESSION['searchname'])
{
    echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/ForgetPassword.php/"</script>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body{
            background-color: #F0FFF0;
        }
    </style>
</head>
<body>
<form method="post">
<center><h1>CHANGE PASSWORD</h1>
<br></br>
<label class="pass">Password: </label>
<input  type="password" name="newpwd" id="pwd" placeholder="Enter New Password">
<br><br>
<label class="pass">Confirm Password: </label>
<input class="con" type="password" name="cnfrm" placeholder="Re-Enter The Password">
<br><br>
<input type="submit" class="change" name="updatepass" value="CHANGE">
</center>
</form>
</body>
</html>
<?php
include "connection.php";
$searchedvalue=$_SESSION['searchname'];
$newpassword=$_POST['newpwd'];
$cngpassword=$_POST['cnfrm'];
if(isset($_POST['updatepass']))
{
    if($newpassword!==$cngpassword)
    {
        echo '<script>alert("password not matched")</script>';
        echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/ForgetPassword.php/"</script>';
    }
    else
    {
        $sql="update `voter_details` set password='$newpassword' where `voter_id`='$searchedvalue'";
        $res=mysqli_query($conn,$sql);

        if($res)
        {
            echo'<script>alert("Password Changed Successfully")</script>';
            echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/VoterLogout.php/"</script>';
        }
    }
}

?>