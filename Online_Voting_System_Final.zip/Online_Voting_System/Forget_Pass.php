
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body{
            /*background-color:#87CEFA;*/
            background: url('Pictures/back_admin.jpg') no-repeat center center/cover;
        }
        .main{
            font-size: 30px;
            font-weight: 50;
        }
        .btn{
            margin-top:20px;
            padding: 5px 20px;
            font-size: 15px;
            font-weight: 50;
        }
    </style>
</head>

<body>
<form method="post">
<center><h1>FORGOT PASSWORD</h1>
<br></br>
<label class="main">Enter Your Adhar Id: </label>
<input type="text" name="a_id">
<br></br>
<input type="submit" name="acsearch" class="btn" value="CONTINUE"></center>
</form>
</body>
</html>
<?php
session_start();
error_reporting(0);
include "connection.php";
$searchname=$_POST['a_id'];
if(isset($_POST['acsearch']))
{
    $sql="select * from `candidate_details` where `ADHAR_ID`='$searchname' ";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res))
    {
        //echo "$searchname";
        $_SESSION['searchname']=$searchname;
        echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/Change_Pass.php/"</script>';
    }
}

?>