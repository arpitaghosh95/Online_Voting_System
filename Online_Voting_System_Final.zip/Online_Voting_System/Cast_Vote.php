<?php
session_start();
include "connection.php";
error_reporting(0);
if(!isset($_SESSION['login'])){
  //echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/VoterLogin.php"</script>';
  
  header("location:/ONLINE_VOTING_SYSTEM/VoterLogin.php");
}

?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registration Form</title>
        <link rel="stylesheet" href="CSS/cast.css">
    </head>
<body>
<form method="post">
<h3> CAST YOUR VOTE </h3>
                
    <input class="radio" type="radio" name="party_name" value="HUNGAMA" id="HUNGAMA">
    <span class="checkmark">HUNGAMA</span>                        
    <br></br>                        
    <input class="radio" type="radio" name="party_name" value="POGO">
    <span class="checkmark">POGO</span>                        
    <br></br>
    <input class="radio" type="radio" name="party_name" value="CARTOON NETWORK">
    <span class="checkmark">CARTOON NETWORK</span>
    <br></br>
    <input type="submit" name="submit" value="CAST" id="submit">
    </form>

    </body>
</html>

<?php
session_start();
error_reporting(0);
include "connection.php";

$voter_id_value = $_SESSION['login'];
$radio_party_voted=$_REQUEST['party_name'];
//echo "YOUR VOTER ID IS:" .$voter_id_value;
if(isset($_POST['submit']))
{
        $sql = "select status from `voter_details` where `voter_id`='$voter_id_value'";
        $res = mysqli_query($conn,$sql);
        if($row=mysqli_fetch_assoc($res))
        {
            if($row['status']==1)
            {
                echo '<script>alert("Already Casted")</script>';
            }
            else{

                $add_vote = "update vote_count set TOTAL_VOTE = (TOTAL_VOTE+1) where PARTY_NAME = '$radio_party_voted'";
                $add = mysqli_query($conn,$add_vote);
                $update = "update voter_details set status = 1 where voter_id = '$voter_id_value'";
                $result = mysqli_query($conn,$update);
                if($result){
                    echo '<script>alert("CASTED SUCCESSFULLY")</script>';
                }
            }
        }      
}

?>