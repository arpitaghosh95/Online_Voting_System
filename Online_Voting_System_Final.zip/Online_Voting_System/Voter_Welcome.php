<?php
session_start();
include "connection.php";
error_reporting(0);
if(!isset($_SESSION['login'])){
  //echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/VoterLogin.php"</script>';
  
  header("location:/ONLINE_VOTING_SYSTEM/VoterLogin.php");
}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>welcome</title>

    <link rel="stylesheet" href="CSS/V_W_Style.css" />
  </head>

  <body>
    <div class="button">
        <button class="details_info_btn"  id="info">My Info</button><br>
        <script >
          document.getElementById("info").onclick = function () {
            location.href = "Voter_Details.php";
          };
        </script>
        
        <button class="details_logout_btn"  id="out">logout</button>
        <script >
          document.getElementById("out").onclick = function () {
            location.href = "VoterLogout.php";
          };
        </script>
      
      </div>
    <div class="grid">
        <div class="grid-item">
        <div class="card">
          <img class="card-img" src="./Pictures/caste_vote.jpg" alt="Rome" />
          <div class="card-content">
            <h1 class="card-header">CAST VOTE</h1>
            <p class="card-text">
            </p>
            <button class="card-btn" id="cast">Visit <span>&rarr;</span></button>
            <script >
                document.getElementById("cast").onclick = function () {
                    location.href = "Cast_Vote.php";
                };
              </script>
          </div>
        </div>
      </div>
      <div class="grid-item">
        <div class="card">
          <img
            class="card-img"
            src="./Pictures/candidate.jpg"
            alt="Grand Canyon"
          />
          <div class="card-content">
            <h1 class="card-header">VIEW CANDIDATE</h1>
            <p class="card-text">
            </p>
            <button class="card-btn" id="candidate">Visit <span>&rarr;</span></button>
            <script >
                document.getElementById("candidate").onclick = function () {
                    location.href = "ShowCandidate.php";
                };
              </script>
          </div>
        </div>
      </div>
      <div class="grid-item">
        <div class="card">
          <img class="card-img" src="./Pictures/results.jpg" alt="Maldives" />
          <div class="card-content">
            <h1 class="card-header">RESULT</h1>
            <p class="card-text">
            </p>
            <button class="card-btn" id="res">Visit <span>&rarr;</span></button>
            <script >
                document.getElementById("res").onclick = function () {
                    location.href = "Show_Result.php";
                };
              </script>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

