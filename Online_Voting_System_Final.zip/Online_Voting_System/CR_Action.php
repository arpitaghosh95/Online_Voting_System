<html>
    <head>
        <title> Welcome_page </TITLE>
    </head>
    <body>
        
    </body>
</html>

<?php
session_start();
error_reporting(0);
include "connection.php";
$id=$_REQUEST['a_id'];
$fname=$_REQUEST['fname'];
$lname=$_REQUEST['lname'];
$email=$_REQUEST['email'];
$contact=$_REQUEST['ph'];
$password=$_REQUEST['pwd'];
$conpas=$_REQUEST['confirm'];
$dob=$_REQUEST['dob'];
$party=$_REQUEST['party'];
$city=$_REQUEST['city'];
$pin=$_REQUEST['pin'];
$state=$_REQUEST['state'];
$gender=$_REQUEST['gender'];
$target_path="Pictures/";
$target_path = $target_path.basename($_FILES['filetoupload']['name']);

if(isset($_POST['REGISTER']))
{
	if($password!==$conpas)
	{
		$_SESSION['passnot']="password not matched";
		header("location:/ONLINE_VOTING_SYSTEM/CandidateRegister.php");
	}
    else{
        $update = "select * from `candidate_details` where `ADHAR_ID` ='$id'";
        $result = mysqli_query($conn,$update);
        if(mysqli_num_rows($result)){
            echo '<script> alert("Already Registered") </script>';
            //header("location:/ONLINE_VOTING_SYSTEM/CandidateRegister.php");
        }
        else{
            if(move_uploaded_file($_FILES['filetoupload']['tmp_name'],$target_path ))
            {
                $x = uniqid(rand());
                $unique = md5($x);
                $sql = "insert into `candidate_details`(`ADHAR_ID`,`FNAME`,`LNAME`,`EMAIL`,`CONTACT`,`PASSWORD`,`DOB`,`PARTY_NAME`,`CITY`,`PIN_CODE`,`STATE`,`GENDER`,`PICTURE`,`UNIQUE_ID`) values ('$id','$fname','$lname','$email','$contact','$password','$dob','$party','$city','$pin','$state','$gender','$target_path','$unique')";
                $res = mysqli_query($conn,$sql);
            }
           else{
               echo '<script>alert("SORRY, Missing data")</script>';
           }
        }
        if($res){
            echo "<center>REGSTERED SUCCESSFULLY</center></br>";
            echo "<center>Your Unique Id is:</center>". $unique;
            //echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/Candidate_Welcome.php/"</script>';
            

        }
        /*else{
            echo "Something went wrong";
        }*/
        
    }
        
}

?>
