<?php
session_start();
include "connection.php";
?>

<!DOCTYPE html>
<html>
<head>
	<style>
		*{
	margin:0;
	padding:0;
}
   body{
		 
      background-color: #A2DBFA;
	  margin-top:40px;
	  background-position:center;
	  background-size:cover;
	  font-family:sans-serif;
	  background-attachment: fixed;
	  }

  form{
  	display: block;
	flex-direction: column;
	height: 400px;
	width: 400px;
	border: 1px solid black;
	align-items: center;
	margin: auto;
	margin-top: 10%;
	background-color: rgba(0, 0, 0, 0.3);  
	box-shadow: inset -5px -1px rgba(0, 0, 0, 0.4);
	border-radius: 25px;
    }
	h2{
		margin-top:20px;
	}
	.main{
		margin-top:10%;
		
	}
	.btn{
		padding:4px 10px 3px;
		
	}
	</style>


</head>
<body>
<form method="post">
	
<center>
	<h2>UPDATE</h2>
<div class="main">
<label>EMAIL: </label>
<input type="email" name="email" value="<?php echo $_GET['em'];?>">
<br></br>
<label>CONTACT: </label>
<input type="text" name="contact" value="<?php echo $_GET['cnt'];?>">
<br></br>
<label>CITY: </label>
<input type="text" name="city" value="<?php echo $_GET['ct'];?>">
<br></br>
<label>PIN_CODE: </label>
<input type="text" name="pin" value="<?php echo $_GET['pin'];?>">
<br></br>
<label>STATE: </label>
<input type="text" name="state" value="<?php echo $_GET['st'];?>">
<br></br>
<input type="submit" class="btn" value="submit" name="Submit">
<input type="reset" class="btn" name="Reset">
</div>
<center>
</form>
</body>
</html>
<?php

$val = $_SESSION['login_id'];
if(isset($_POST['Submit']))
{
$email=$_POST['email'];
$contact=$_POST['contact'];
$city=$_POST['city'];
$pin=$_POST['pin'];
$state=$_POST['state'];

$query = "update candidate_details set EMAIL='$email', CONTACT='$contact', CITY='$city', PIN_CODE='$pin', STATE='$state' where `UNIQUE_ID`='$val'";
$data = mysqli_query($conn,$query);
if($data)
{
echo'<script> alert("record Updated sucessfully")</script>';
echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/View_Details.php/"</script>';
}
}
?>