<!DOCTYPE html>
<html>
<head> 
<title>Login_form</title>
<link rel="stylesheet" href="CSS/LoginStyle.css">  
</head>
<body>
<form method="post">
<h1>Login Form</h1>
<input type="text" name="v_id" class="box" placeholder="Enter voter id">
<input type="password" name="password" class="box" placeholder="Enter password">
<input type="submit" name="submit" value="LOGIN" id="submit"> 
<br></br>
<center><a style="margin-left:20;" class="forgot" href="/ONLINE_VOTING_SYSTEM/ForgetPassword.php">Forgot Password?</a></center>
</form>
</body>
</html>


<?php
session_start();
error_reporting(0);
include "connection.php";
$id=$_POST['v_id'];
$password=$_POST['password'];
if(isset($_POST['submit']))
{
    $sql = "select * from `voter_details` where `voter_id`='$id' and `password`='$password'";
    $res = mysqli_query($conn,$sql);
    if(mysqli_num_rows($res))
    {
        $_SESSION['login']=$id;
        header("location:/ONLINE_VOTING_SYSTEM/Voter_Welcome.php");
    }
    else
    {
        echo'<script>alert("WRONG PASSWORD")</script>';
        //echo'<script>window.location.href="/ONLINE_VOTING_SYSTEM/VoterLogin.php/"</script>';
    }
}
?>